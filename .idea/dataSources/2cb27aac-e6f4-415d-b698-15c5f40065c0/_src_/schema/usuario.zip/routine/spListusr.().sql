CREATE PROCEDURE spListusr()
  BEGIN
	SET sql_safe_updates = 0;
    
    DROP TEMPORARY TABLE IF EXISTS tblg;
    
    CREATE TEMPORARY TABLE tblg
    select A.mdl_id, B.mdl_nom, A.mnu_id, cast('' as char(50)) as 'mnu_nom', C.nomusr, C.mail, B.mdl_ext
	from pweb_rspnsbl A inner join pweb_mdl B on (A.mdl_id = B.mdl_id) 
						inner join pweb_usr C on (A.idusr = C.idusr);
    
    UPDATE tblg E INNER JOIN pweb_mnu F on (E.mnu_id = F.mnu_id)
	SET E.mnu_nom = F.mnu_nom;
    
    SELECT * from tblg ORDER BY mdl_nom, mnu_nom, nomusr;
    
    DROP TEMPORARY TABLE tblg;
    
	SET sql_safe_updates = 1;
END;
