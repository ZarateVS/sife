CREATE PROCEDURE SPGETEMPRESAS_ACTIVASXUSUARIO(IN USR INT)
  BEGIN

	SET sql_safe_updates = 0;
    
    DROP temporary TABLE IF EXISTS tblg;
    
    CREATE temporary TABLE tblg
    select empresa, nombre, cast('' as char(1)) as 'activo'
	from empresa; 
    
    UPDATE tblg
    set activo = CASE WHEN empresa in (select empresa from pweb_usremp where idusr = usr) THEN 1 ELSE 0 END;
                            
	SELECT * FROM tblg ORDER BY	nombre;
    
    DROP temporary TABLE tblg;
    
	SET sql_safe_updates = 1;

END;
