CREATE PROCEDURE SPGETMENUS_ACTXROL(IN MDL INT, IN ROL INT)
  BEGIN

	SET sql_safe_updates = 0;
    
    DROP temporary TABLE IF EXISTS tblg;
    
    CREATE temporary TABLE tblg
    select cat_nom, mnu_id, mnu_nom, cast('' as char(1)) as 'activo'
	from pweb_mdl A inner join pweb_mnu B on (A.mdl_id = B.mnu_sis) 
					inner join pweb_catmnu D on (B.mnu_cat = D.cat_id)
	where A.mdl_id = MDL;
        
    UPDATE tblg
    set activo = CASE WHEN mnu_id in (select mnu_id from pweb_rolmnu where idrol = ROL) THEN 1 ELSE 0 END;
                            
	SELECT * FROM tblg ORDER BY	cat_nom, mnu_nom;
    
    DROP temporary TABLE tblg;
    
	SET sql_safe_updates = 1;

END;
