CREATE PROCEDURE SPCREARMENU(IN USRID INT)
  BEGIN
	Select A.id_mnu, C.rol_insert, C.rol_update, C.rol_delete, A.mnu_url, A.mnu_nom, B.id_cat, B.nombre, B.icono, A.submenu
    FROM sis_mnu A INNER JOIN sis_catmnu B on ( A.id_cat = B.id_cat) INNER JOIN sis_usrmnu C on (A.id_mnu = C.id_mnu)
    WHERE C.idusr = USRID
    ORDER BY b.nombre, A.orden;
END;
