CREATE PROCEDURE SPGETZONAS_ACTIVASXUSUARIO(IN USR INT)
  BEGIN

	SET sql_safe_updates = 0;
    
    DROP temporary TABLE IF EXISTS tblg;
    
    CREATE temporary TABLE tblg
    select clave, nombre, cast('' as char(1)) as 'activo'
	from supervisor; 
    
    UPDATE tblg
    set activo = CASE WHEN clave in (select clave from pweb_supusr where idusr = usr) THEN 1 ELSE 0 END;
                            
	SELECT * FROM tblg ORDER BY	nombre;
    
    DROP temporary TABLE tblg;
    
	SET sql_safe_updates = 1;

END;
